#pragma once

enum ClientEvent {
    DISCONNECTED,
    INCOMING_MSG
};