#include <iostream>
#include <csignal>
#include "include/tcp_client.h"
#include <fstream>
#include <cstring>
using namespace std;

const int MAX_SEND_LENGTH=4096;
TcpClient client;

void sig_exit(int s)
{
    cout<<"Closing client ... \n";
    pipe_ret_t finishRet = client.close();
    if(finishRet.isSuccessful())
    {
        cout<<"Client closed \n";
    }
    else
    {
        cout<<"Failed to close client \n";
    }
    exit(0);
}


void onIncomingMsg(const char *msg,size_t size)
{
    std::cout << "Got msg from server: " << msg << "\n";
}

void onDisconnection(const pipe_ret_t & ret) {
    std::cout << "Server disconnected: " << ret.message() << "\n";
}

void printMenu() {
    std::cout << "select one of the following options: \n" <<
                 "1. send message to server\n" <<
                 "2. close client and exit\n";
}

int getMenuSelection() {
    int selection = 0;
    std::cin >> selection;
    if (!std::cin) {
        throw std::runtime_error("invalid menu input. expected a number, but got something else");
    }
    std::cin.ignore (std::numeric_limits<std::streamsize>::max(), '\n');
    return selection;
}

bool handleMenuSelection(int selection) {
    static const int minSelection = 1;
    static const int maxSelection = 2;
    if (selection < minSelection || selection > maxSelection) {
        std::cout << "invalid selection: " << selection <<
                     ". selection must be b/w " << minSelection << " and " << maxSelection << "\n";
        return false;
    }
    switch (selection) {
        case 1: { // send message to server
            std::cout << "enter message to send:\n";
            std::string message;
            std::cin >> message;

            char s[MAX_SEND_LENGTH];
            FILE *infile;
            infile = fopen("/home/ly/Downloads/smoke/smoke/6966.jpg","r");
            if(!infile)
            {
                std::cerr<<"open failed \n";
                exit(1);
            }
            fseek(infile,0,SEEK_END);
            int length=ftell(infile);


            rewind(infile);
            size_t sumsize=0;
            while(!feof(infile))
            {
                size_t size=fread(s,1,sizeof(s),infile);
                if(size<=0) break;
                pipe_ret_t sendRet = client.sendMsg(s,size);
//                pipe_ret_t sendRet = client.sendMsg(message.c_str(), message.size());
                if (!sendRet.isSuccessful()) {
                    std::cout << "Failed to send message: " << sendRet.message() << "\n";
                } else {
                    sumsize+=size;
                    std::cout << "message was sent successfuly:"<<size<<"\n";
                }
            }
            fclose(infile);
            std::cout<<"send puc size="<<sumsize<<std::endl;

            break;
        }
        case 2: { // close client
            const pipe_ret_t closeResult = client.close();
            if (!closeResult.isSuccessful()) {
                std::cout << "closing client failed: " << closeResult.message() << "\n";
            } else {
                std::cout << "closed client successfully\n";
            }
            return true;
        }
        default: {
            std::cout << "invalid selection: " << selection <<
                      ". selection must be b/w " << minSelection << " and " << maxSelection << "\n";
        }
    }
    return false;
}


int main()
{

    signal(SIGINT,sig_exit);
    client_observer_t observer;
    observer.wantedIP="127.0.0.1";
    observer.incomingPacketHandler = onIncomingMsg;
    observer.disconnectionHandler = onDisconnection;
    client.subscribe(observer);


A:   bool connected=false;

    while(!connected)
    {
        pipe_ret_t connectRet = client.connectTo("192.168.22.132",6789);
        connected = connectRet.isSuccessful();
        if(connected)
        {
            std::cout<<"Client connected successfully\n";
        }
        else
        {
            std::cout << "Client failed to connect: " << connectRet.message() << "\n"
                                 << "Make sure the server is open and listening\n\n";
            sleep(2);
            std::cout << "Retrying to connect...\n";
        }
    }

    bool shouldTerminate = false;
    while(!shouldTerminate)
    {
        if(!client.isConnected()) goto A;
        printMenu();
        int selection = getMenuSelection();
        shouldTerminate = handleMenuSelection(selection);
    }
    sleep(10);
    cout << "Hello World!" << endl;
    return 0;
}
